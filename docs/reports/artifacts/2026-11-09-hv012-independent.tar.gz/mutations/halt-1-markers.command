sh tests/check_svm_output.sh tests/svm/expect/s2perm-1.txt tests/svm/expect/s2perm-forbid.txt 
