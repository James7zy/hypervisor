#!/bin/bash
export PATH=/tmp/wrapbin:$PATH LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib CROSS_COMPILE=aarch64-linux-gnu-
base=/tmp/hv012-independent/mutations
run() { name=$1; shift; printf '%q ' "$@" > "$base/$name.command"; echo >> "$base/$name.command"; "$@" > "$base/$name.log" 2>&1; echo $? > "$base/$name.exit"; }
cd "$base/noclass"
run noclass-build make CONFIG=hypervisor/arch/arm64/configs/qemu_virt_defconfig build/host/data_abort_test
run noclass-behavior ./build/host/data_abort_test
for variant in permissions halt; do
 cd "$base/$variant"
 run $variant-build make CONFIG=hypervisor/arch/arm64/configs/qemu_virt_defconfig BUILD_DIR=build/test-s2perm HV_GUEST=svm_s2perm all build/test-s2perm/svm/svm-s2perm-0.bin build/test-s2perm/svm/svm-s2perm-1.bin build/test-s2perm/svm/svm-s2perm_survivor.bin
 for probe in 0 1; do
  export HV_NR_CPUS=4 HYPERVISOR_ELF=build/test-s2perm/hypervisor.elf SVM_BIN=build/test-s2perm/svm/svm-s2perm-$probe.bin SVM_BIN2=build/test-s2perm/svm/svm-s2perm_survivor.bin
  run $variant-$probe-qemu timeout 10 ./scripts/run-qemu.sh </dev/null
  run $variant-$probe-markers sh tests/check_svm_output.sh tests/svm/expect/s2perm-$probe.txt tests/svm/expect/s2perm-forbid.txt < "$base/$variant-$probe-qemu.log"
  run $variant-$probe-ordered python3 -B tests/check_s2perm_output.py "$probe" "$base/$variant-$probe-qemu.log"
 done
 done
