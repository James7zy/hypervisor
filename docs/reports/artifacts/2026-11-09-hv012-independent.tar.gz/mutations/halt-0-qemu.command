timeout 10 ./scripts/run-qemu.sh 
