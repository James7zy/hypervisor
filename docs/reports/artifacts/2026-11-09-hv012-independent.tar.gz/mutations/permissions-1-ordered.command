python3 -B tests/check_s2perm_output.py 1 /tmp/hv012-independent/mutations/permissions-1-qemu.log 
