cd /tmp/hv012-independent/history/7736e8f
gcc -Wall -Wextra -Werror -O2 -g -fno-builtin -U_FORTIFY_SOURCE -Ihypervisor/include -Itests/host -Ihypervisor/arch/arm64/include -Ihypervisor/arch/arm64/vmexit -o data_abort_test tests/host/data_abort_test.c hypervisor/arch/arm64/vmexit/data_abort_mmio.c hypervisor/common/io/mmio.c
