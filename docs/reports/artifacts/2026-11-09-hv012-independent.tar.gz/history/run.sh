#!/bin/bash
export PATH=/tmp/wrapbin:$PATH LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib CROSS_COMPILE=aarch64-linux-gnu-
for rev in ff78ded a94d4bc; do
 cd /tmp/hv012-independent/history/$rev
 printf '%s\n' 'make CONFIG=hypervisor/arch/arm64/configs/qemu_virt_defconfig build/host/data_abort_test; ./build/host/data_abort_test' > ../$rev.command
 make CONFIG=hypervisor/arch/arm64/configs/qemu_virt_defconfig build/host/data_abort_test > ../$rev.build.log 2>&1; echo $? > ../$rev.build.exit
 ./build/host/data_abort_test > ../$rev.behavior.log 2>&1; echo $? > ../$rev.behavior.exit
 done
