python3 -B tests/check_s2perm_output.py 1 /tmp/hv012-independent/checker-fix/boundaries/xn-fault-trailing-quote.log
