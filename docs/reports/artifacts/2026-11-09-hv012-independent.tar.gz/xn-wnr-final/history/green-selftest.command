python3 -B tests/check_s2perm_output_test.py
