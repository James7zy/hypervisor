from pathlib import Path
import json,subprocess,os,sys
base=Path('/tmp/hv012-independent');b=base/'xn-wnr-final';out=b/(sys.argv[1] if len(sys.argv)>1 else 'runner-replay');out.mkdir(exist_ok=True)
cases=[dict(suite=x['suite'],path=x['path'],probe=x['probe'],expected=x['expected']) for x in json.loads((b/'known-results.json').read_text())]
normal=[]
for d in [*sorted(base.glob('round-*')),base/'final-qemu',*sorted((base/'checker-fix').glob('round-*')),base/'checker-fix/full-test-raw',*sorted(b.glob('round-*')),b/'full-test-raw']:
 for probe in [0,1]:
  p=d/f's2perm-{probe}.log'
  if p.exists():normal.append(dict(suite='normal-raw',path=str(p),probe=probe,expected=True))
for probe,kind in [(0,'ro'),(1,'xn')]:normal.append(dict(suite='normal-raw',path=str(base/'synthetic'/f'{kind}-original.log'),probe=probe,expected=True))
cases.extend(normal)
for v in ['permissions','halt']:
 for probe in [0,1]:cases.append(dict(suite='real-mutation',path=str(base/'mutations'/f'{v}-{probe}-qemu.log'),probe=probe,expected=False))
results=[]
for i,c in enumerate(cases):
 name=f'{i:03}-{c["suite"]}-{Path(c["path"]).stem}';raw=out/(name+'.qemu.log')
 cmd=['sh','tests/run_s2perm_test.sh',str(c['probe']),str(raw)]
 env=os.environ.copy();env['PATH']=str(b/'replay-bin')+':'+env['PATH'];env['HV012_REPLAY_SOURCE']=c['path']
 (out/(name+'.command')).write_text('HV012_REPLAY_SOURCE='+c['path']+' PATH='+str(b/'replay-bin')+':$PATH '+' '.join(cmd)+'\n')
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.exit')).write_text(str(r.returncode)+'\n')
 results.append(dict(**c,actual=r.returncode==0,runner_exit=r.returncode,replay_timeout_exit=int(Path(str(raw)+'.exit').read_text())))
(b/'runner-results.json').write_text(json.dumps(results,indent=2)+'\n')
for suite in ['original32','boundaries68','normal-raw','real-mutation']:
 rows=[r for r in results if r['suite']==suite];print(suite,len(rows),'files;',sum(r['actual']!=r['expected'] for r in rows),'mismatches')
print('Complete unchanged runner; timeout replay only, no QEMU spawned.')
sys.exit(any(r['actual']!=r['expected'] for r in results))
