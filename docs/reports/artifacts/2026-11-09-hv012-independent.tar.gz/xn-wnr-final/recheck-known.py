from pathlib import Path
import importlib.util,json,sys
b=Path('/tmp/hv012-independent/xn-wnr-final')
spec=importlib.util.spec_from_file_location('checker','tests/check_s2perm_output.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for suite,p in [('original32','/tmp/hv012-independent/checker-fix/history/74b2222-corpus.json'),('boundaries68','/tmp/hv012-independent/checker-fix/independent-boundaries.json')]:
 rows=json.loads(Path(p).read_text());count=0
 for row in rows:
  text=Path(row['path']).read_bytes().decode();actual=m.check(text,row['probe'])
  results.append(dict(suite=suite,path=row['path'],probe=row['probe'],expected=row['expected'],actual=actual,crlf='\r\n' in text))
  count+=actual!=row['expected']
 print(suite,len(rows),'cases;',count,'mismatches')
(b/'known-results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(any(x['actual']!=x['expected'] for x in results))
