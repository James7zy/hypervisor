python3 -B tests/check_s2perm_output.py 0 /tmp/hv012-independent/xn-wnr-final/full-test-raw/s2perm-0.log 
