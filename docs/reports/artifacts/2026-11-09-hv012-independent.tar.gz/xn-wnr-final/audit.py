from pathlib import Path
import subprocess,json,hashlib
b=Path('/tmp/hv012-independent/xn-wnr-final')
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='05954ec92b4ab03a4a81df120d8aed42cc2560a7'
for line in (b/'gates.status').read_text().splitlines():
 name,code=line.split();assert code=='0' and (b/(name+'.exit')).read_text().strip()=='0'
for name,value in [('history/red-selftest',1),('history/green-selftest',0),('history/red-blocker',0),('history/green-blocker',1),('known',0),('runner-final',0),('initial-evidence-preserved',0),('checker-fix-evidence-preserved',0)]:
 assert int((b/(name+'.exit')).read_text())==value
assert '80 checks, 3 failures' in (b/'history/red-selftest.log').read_text()
assert '80 checks, 0 failures' in (b/'history/green-selftest.log').read_text()
r=json.loads((b/'known-results.json').read_text());assert len(r)==100 and all(x['actual']==x['expected'] for x in r)
assert sum(x['crlf'] for x in r)==2
r=json.loads((b/'runner-results.json').read_text());assert len(r)==130 and all(x['actual']==x['expected'] for x in r)
assert sum(x['suite']=='normal-raw' for x in r)==26
assert all(x['runner_exit']==1 for x in r if x['path'].endswith('/xn-fault-trailing-quote.log') or x['suite']=='real-mutation')
r=json.loads((b/'qemu-summary.json').read_text());assert len(r)==8 and all(x['qemu_exit']==124 and x['post_count']==199 for x in r)
for base in ['74b2222','8d538ef']:
 assert subprocess.check_output(['git','diff','--name-only',base,'HEAD'],text=True).splitlines()==['tests/check_s2perm_output.py','tests/check_s2perm_output_test.py']
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
assert not subprocess.check_output(['git','diff','--name-only']).strip()
for line in (b/'preserved-before.sha256').read_text().splitlines():
 digest,path=line.split(maxsplit=1);assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
lines=[]
for v in ['noclass','permissions','halt']:
 for f in ['hypervisor/arch/arm64/vmexit/data_abort_mmio.c','hypervisor/arch/arm64/vmexit/vmexit.c','tests/svm/s2perm_fixture.c']:
  assert (Path('/tmp/hv012-independent/mutations')/v/f).read_bytes()==subprocess.check_output(['git','show','HEAD:'+f]);lines.append(v+' '+f+' matches final HEAD')
(b/'old-mutation-restoration.txt').write_text('\n'.join(lines)+'\n')
report=Path('docs/reports/2026-11-09-hv012-abort-permissions-verification.md').read_text()
assert all(l==l.rstrip() for l in report.splitlines())
assert '05954ec' in report and '**最终阻塞：无。**' in report
print('Final evidence audit PASS: old evidence intact; 80 selftests, 32+68 known cases, 130 runner replays, all requested live gates; no staged files or production working changes.')
