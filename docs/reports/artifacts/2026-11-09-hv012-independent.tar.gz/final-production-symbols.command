aarch64-linux-gnu-nm build/independent-production/hypervisor.elf 
