aarch64-linux-gnu-objdump -h -d build/test-s2perm/svm/svm-s2perm-1.elf 
