#!/bin/bash
cd /home/corsair/Music/virtual/hypervisor
export PATH=/tmp/wrapbin:$PATH LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib CROSS_COMPILE=aarch64-linux-gnu-
base=/tmp/hv012-independent
run() { name=$1; shift; printf '%q ' "$@" > "$base/final-$name.command"; echo >> "$base/final-$name.command"; "$@" > "$base/final-$name.log" 2>&1; echo $? > "$base/final-$name.exit"; }
run clean make clean
run host make host-test
run test make test
mkdir -p "$base/final-qemu"
cp build/test-s2perm/s2perm-*.log* "$base/final-qemu/"
for probe in 0 1; do run checker-$probe python3 -B tests/check_s2perm_output.py $probe "$base/final-qemu/s2perm-$probe.log"; done
run probe-elf make BUILD_DIR=build/test-s2perm HV_GUEST=svm_s2perm build/test-s2perm/svm/svm-s2perm-0.elf build/test-s2perm/svm/svm-s2perm-1.elf
for probe in 0 1; do run disassembly-$probe aarch64-linux-gnu-objdump -h -d build/test-s2perm/svm/svm-s2perm-$probe.elf; done
run production make BUILD_DIR=build/independent-production HV_GUEST=linux all
run production-symbols aarch64-linux-gnu-nm build/independent-production/hypervisor.elf
