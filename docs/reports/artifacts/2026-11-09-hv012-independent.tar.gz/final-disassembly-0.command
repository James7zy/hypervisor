aarch64-linux-gnu-objdump -h -d build/test-s2perm/svm/svm-s2perm-0.elf 
