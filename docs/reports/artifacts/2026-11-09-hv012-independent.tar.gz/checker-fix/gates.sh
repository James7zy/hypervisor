#!/bin/bash
cd /home/corsair/Music/virtual/hypervisor
export PATH=/tmp/wrapbin:$PATH LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib CROSS_COMPILE=aarch64-linux-gnu-
base=/tmp/hv012-independent/checker-fix
run() { name=$1; shift; printf '%q ' "$@" > "$base/$name.command"; echo >> "$base/$name.command"; "$@" > "$base/$name.log" 2>&1; rc=$?; echo "$rc" > "$base/$name.exit"; echo "$name $rc" >> "$base/gates.status"; }
run host make host-test
run clean make clean
run test make test
mkdir -p "$base/full-test-raw"
cp build/test-s2perm/s2perm-*.log* "$base/full-test-raw/"
for probe in 0 1; do run full-test-checker-$probe python3 -B tests/check_s2perm_output.py "$probe" "$base/full-test-raw/s2perm-$probe.log"; done
for i in 1 2 3; do
 run s2perm-$i make test-qemu-s2perm
 mkdir -p "$base/round-$i"
 cp build/test-s2perm/s2perm-*.log* "$base/round-$i/"
 for probe in 0 1; do run round-$i-checker-$probe python3 -B tests/check_s2perm_output.py "$probe" "$base/round-$i/s2perm-$probe.log"; done
 done
run linux make test-linux
cp /tmp/linux-xvm.log "$base/linux-raw.log"
run x86 make test-x86-stub
run static make check-arch-boundary check-offsets check-offsets-target
