import importlib.util,json,sys
from pathlib import Path
checker=Path(sys.argv[1]); output=Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('checker',checker);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source=Path('/tmp/hv012-independent/synthetic')
cases=json.loads((source/'results.json').read_text())
for kind in ['ro','xn']: cases.append({'probe':kind,'case':'original','expected':True})
results=[]
for c in cases:
 p=source/(c['probe']+'-'+c['case']+'.log'); probe=0 if c['probe']=='ro' else 1
 actual=m.check(p.read_text(),probe)
 results.append(dict(path=str(p),probe=probe,expected=c['expected'],actual=actual))
output.write_text(json.dumps(results,indent=2)+'\n')
failed=[r for r in results if r['expected']!=r['actual']]
print(f'{len(results)} cases, {len(failed)} mismatches')
for r in failed:print(r)
sys.exit(bool(failed))
