make test-qemu-s2perm 
