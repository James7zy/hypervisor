python3 -B tests/check_s2perm_output.py 0 /tmp/hv012-independent/checker-fix/full-test-raw/s2perm-0.log 
