python3 -B tests/check_s2perm_output.py 1 /tmp/hv012-independent/checker-fix/full-test-raw/s2perm-1.log 
