from pathlib import Path
import subprocess,json,hashlib
b=Path('/tmp/hv012-independent/checker-fix')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='74b2222dcd5b8578b99d5959d64710529906d607'
for line in (b/'gates.status').read_text().splitlines():
 name,code=line.split();assert code=='0';assert (b/(name+'.exit')).read_text().strip()=='0'
for rev,rc in [('feeb8fb',1),('74b2222',0)]:
 assert int((b/f'history/{rev}-selftest.exit').read_text())==rc
 assert int((b/f'history/{rev}-corpus.exit').read_text())==rc
r=json.loads((b/'independent-boundaries.json').read_text());bad=[x for x in r if x['actual']!=x['expected']]
assert len(r)==68 and len(bad)==1 and bad[0]['case']=='fault-trailing-quote' and bad[0]['probe']==1
r=json.loads((b/'runner-replay.json').read_text());bad=[x for x in r if x['actual']!=x['expected']]
assert len(r)==37 and len(bad)==1 and bad[0]['runner_exit']==0
assert all(x['runner_exit']==1 for x in r if '/mutations/' in x['path'])
assert all(x['qemu_exit']==124 and x['post_count']>0 for x in json.loads((b/'qemu-summary.json').read_text()))
assert subprocess.check_output(['git','diff','--name-only','8d538ef','HEAD'],text=True).splitlines()==['tests/check_s2perm_output.py','tests/check_s2perm_output_test.py']
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
assert not subprocess.check_output(['git','diff','--name-only']).strip()
for line in (b/'preserved-before.sha256').read_text().splitlines():
 digest,path=line.split(maxsplit=1);assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
restored=[]
for v in ['noclass','permissions','halt']:
 for file in ['hypervisor/arch/arm64/vmexit/data_abort_mmio.c','hypervisor/arch/arm64/vmexit/vmexit.c','tests/svm/s2perm_fixture.c']:
  assert (Path('/tmp/hv012-independent/mutations')/v/file).read_bytes()==subprocess.check_output(['git','show','HEAD:'+file])
  restored.append(v+' '+file+' matches current production source')
(b/'old-mutation-restoration.txt').write_text('\n'.join(restored)+'\n')
report=Path('docs/reports/2026-11-09-hv012-abort-permissions-verification.md').read_text();assert all(l==l.rstrip() for l in report.splitlines())
assert '[0x403f0000,0x40400000)' in report and '合入 BLOCKED' in report
print('Evidence consistency PASS; merge BLOCKED: XN fault-trailing-quote still accepted. All scheduled builds finished; no production edits or staged files.')
