from pathlib import Path
import subprocess,json,os
b=Path('/tmp/hv012-independent/checker-fix');d=b/'runner-replay'
cases=json.loads((b/'history/74b2222-corpus.json').read_text())
cases.append(dict(path=str(b/'boundaries/xn-fault-trailing-quote.log'),probe=1,expected=False))
for variant in ['permissions','halt']:
 for probe in [0,1]: cases.append(dict(path=f'/tmp/hv012-independent/mutations/{variant}-{probe}-qemu.log',probe=probe,expected=False))
results=[]
for i,c in enumerate(cases):
 p=Path(c['path']);name=f'{i:02}-{p.stem}';raw=d/(name+'.qemu.log')
 env=os.environ.copy();env['PATH']=str(b/'replay-bin')+':'+env['PATH'];env['HV012_REPLAY_SOURCE']=str(p)
 cmd=['sh','tests/run_s2perm_test.sh',str(c['probe']),str(raw)]
 (d/(name+'.command')).write_text('HV012_REPLAY_SOURCE='+str(p)+' PATH='+str(b/'replay-bin')+':$PATH '+' '.join(cmd)+'\n')
 with (d/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (d/(name+'.exit')).write_text(str(r.returncode)+'\n')
 results.append(dict(path=str(p),probe=c['probe'],expected=c['expected'],actual=r.returncode==0,runner_exit=r.returncode,replay_timeout_exit=int(Path(str(raw)+'.exit').read_text())))
(b/'runner-replay.json').write_text(json.dumps(results,indent=2)+'\n')
bad=[r for r in results if r['expected']!=r['actual']]
print(len(results),'complete-runner replays,',len(bad),'mismatches; no QEMU spawned')
for r in bad:print(r)
raise SystemExit(bool(bad))
