from pathlib import Path
import importlib.util,json,re,sys
b=Path('/tmp/hv012-independent/checker-fix');d=b/'boundaries';d.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('checker','tests/check_s2perm_output.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for probe,kind in [(0,'ro'),(1,'xn')]:
 raw=(Path('/tmp/hv012-independent/synthetic')/(kind+'-good.log')).read_text()
 lines=raw.splitlines(True);fault=next(l for l in lines if l.startswith('[hv] s2 fault:'))
 read=next(l for l in lines if l.startswith('SVM: s2perm '+kind.upper()+' read ok'))
 progress=[l for l in lines if l.startswith('SVM: s2perm survivor')][-1]
 cases={'LF':(raw,True),'CRLF':(raw.replace('\n','\r\n'),True)}
 for event,line in [('fault',fault),('read',read),('progress',progress)]:
  for form,replacement in [('quoted-prefix','DIAGNOSTIC REPLAY: '+line),('leading-space',' '+line),('trailing-quote',line.rstrip('\n')+"'\n")]:
   cases[event+'-'+form]=(raw.replace(line,replacement),False)
 for key in re.findall(r'(\w+)=',fault):
  value=re.search(r'\b'+key+r'=([^\s]+)',fault)[1]
  cases['duplicate-'+key]=(raw.replace(fault,fault.rstrip('\n')+f' {key}={value}\n'),False)
 cases['duplicate-unknown-key']=(raw.replace(fault,fault.rstrip('\n')+' extra=0 extra=0\n'),False)
 esr=int(re.search(r'esr=(0x[0-9a-f]+)',fault)[1],16)
 for name,value in [('raw-EC',esr^(4<<26)),('raw-FSC',esr^8),('raw-S1PTW',esr|128),('raw-overflow',esr|(1<<32)),('raw-negative',-1)]:
  cases[name]=(raw.replace(f'esr={esr:#x}',f'esr={value:#x}'),False)
 if probe==0:
  for name,value in [('raw-CM',esr|256),('raw-WnR',esr^64)]:cases[name]=(raw.replace(f'esr={esr:#x}',f'esr={value:#x}'),False)
 cases['two-valid-faults']=(raw.replace(fault,fault+fault),False)
 cases['old-progress-replay']=(raw.replace(progress,progress.replace(re.search(r'progress=([0-9a-f]+)',progress)[1],'00000001')),False)
 for name,(text,expected) in cases.items():
  p=d/(kind+'-'+name+'.log');p.write_text(text);actual=m.check(text,probe)
  results.append(dict(probe=probe,case=name,path=str(p),expected=expected,actual=actual))
(b/'independent-boundaries.json').write_text(json.dumps(results,indent=2)+'\n')
failed=[r for r in results if r['actual']!=r['expected']]
print(len(results),'cases;',len(failed),'mismatches')
for r in failed:print(r)
sys.exit(bool(failed))
