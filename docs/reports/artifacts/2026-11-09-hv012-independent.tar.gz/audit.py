from pathlib import Path
import json,subprocess
b=Path('/tmp/hv012-independent')
def rc(path,expected):
 actual=int((b/path).read_text());assert actual==expected,(path,actual,expected)
for name in ['host','clean','test','s2perm-1','s2perm-2','s2perm-3','linux','x86','static','final-clean','final-host','final-test','final-production','final-probe-elf','final-disassembly-0','final-disassembly-1']:
 rc(name+'.exit',0)
for rev,expected in [('7736e8f',1),('ff78ded',1),('a94d4bc',0)]:
 rc('history/'+rev+'.build.exit',0);rc('history/'+rev+'.behavior.exit',expected)
for v in ['noclass','permissions','halt']:rc('mutations/'+v+'-build.exit',0)
rc('mutations/noclass-behavior.exit',1)
for v in ['permissions','halt']:
 for probe in [0,1]:
  prefix=f'mutations/{v}-{probe}'
  rc(prefix+'-qemu.exit',124);rc(prefix+'-markers.exit',int(v=='permissions'));rc(prefix+'-ordered.exit',1)
  s=(b/(prefix+'-qemu.log')).read_text()
  assert 'fixture: vm=0 checked' in s and 'fixture: vm=1 checked' in s
  if v=='permissions':assert ('RO STORE SURVIVED' if probe==0 else 'XN ENTERED') in s and 's2 fault:' not in s
  else:assert 's2 fault:' in s and 'survivor vm=' not in s
for n in [1,2,3]:
 for probe in [0,1]:rc(f'round-{n}/s2perm-{probe}.log.exit',124);rc(f'round-{n}/checker-{probe}.exit',0)
for probe in [0,1]:rc(f'final-qemu/s2perm-{probe}.log.exit',124);rc(f'final-checker-{probe}.exit',0)
r=json.loads((b/'synthetic/results.json').read_text());bad=[x for x in r if x['expected']!=x['actual']]
assert len(r)==30 and len(bad)==6
assert {x['case'] for x in bad}=={'duplicate_wrong_fields','quoted_progress_only','inconsistent_esr'}
assert 'svm_s2perm_fixture' not in (b/'final-production-symbols.log').read_text()
assert b's2perm fixture' not in Path('build/independent-production/hypervisor.elf').read_bytes()
assert not subprocess.check_output(['git','diff','--cached','--name-only']).strip()
subprocess.run(['git','diff','--exit-code','HEAD','--','hypervisor','tests','Makefile'],check=True)
report=Path('docs/reports/2026-11-09-hv012-abort-permissions-verification.md').read_text()
assert all(line==line.rstrip() for line in report.splitlines())
print('Evidence audit PASS: gate codes, history behavior, real mutations, 3 rounds, final rebuild, source isolation; 6 synthetic false positives retained (not declared green).')
