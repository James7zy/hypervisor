# HV-012 独立验收原始证据

被测 HEAD：8d538ef499bd7715e661955b953c35e324d052a1。所有时间/结果均来自独立执行，不复制研发日志。

- gates.sh：首轮门禁，*.command / *.exit / *.log；round-{1,2,3}：三轮原始 RO/XN、QEMU exit 和另行执行 checker exit。
- final.sh：未变异真实树 clean 后重建/重跑；final-qemu：最后正常原始日志。
- history/run.sh：ff78ded / a94d4bc archive 的构建、行为原始退出码。initial-no-config 是首次配置失败，不计作 RED。
- history/7736e8f.command：等行为提取 archive，移入 ff78ded 原始 test 后独立编译；行为 RED。
- mutations/*.patch：隔离变异；run.sh 在已应用 patch 的相应 archive 目录运行（复现需先分别 patch -p1 < ../{name}.patch）。
- mutations/noclass-gate-only-*：只移除 admission if 的初次试验，仍保留分类的 IPA 结果；最终 noclass 还恢复原始 HPFAR/FAR 组合，直接验证 permission spy 红。
- mutations/*-qemu.{command,log,exit} 和 *-{markers,ordered}.{command,log,exit}：分别保存 QEMU timeout124、checker 结果。环境使用 HV_NR_CPUS=4、各 archive build/test-s2perm ELF、对应 probe BIN 和 survivor BIN（见 run.sh）。
- mutations/restoration.txt：变异后的三个 archive 源文件均恢复至 HEAD，make clean 清除变异产物；复现不能直接运行已还原目录而省略应用 patch。
- synthetic/run.py：以独立 QEMU 的真实记录派生 30 例；results.json 明确保留预期与实际，并不将 script exit0 冒充所有断言满足。
- spec：独立下载的寄存器镜像及纯文本、curl exit；reference-excerpts.txt 为审查节选，完整原文 HTML 保留。
- full.diff：f31a22b..8d538ef 完整 diff；environment.txt：工具链/平台/受保护文件初始摘要。

真实树仅写 docs/reports/2026-11-09-hv012-abort-permissions-verification.md；父线程可能另写文档，未触碰生产源码或脚本。未执行 commit/push/checkout/stage。
