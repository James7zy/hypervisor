#!/bin/bash
cd /home/corsair/Music/virtual/hypervisor
export PATH=/tmp/wrapbin:$PATH LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib CROSS_COMPILE=aarch64-linux-gnu-
run() { name=$1; shift; printf '%q ' "$@" > /tmp/hv012-independent/$name.command; echo >> /tmp/hv012-independent/$name.command; "$@" > /tmp/hv012-independent/$name.log 2>&1; rc=$?; echo "$rc" > /tmp/hv012-independent/$name.exit; echo "$name $rc" >> /tmp/hv012-independent/gates.status; }
run host make host-test
run clean make clean
run test make test
for i in 1 2 3; do
 run s2perm-$i make test-qemu-s2perm
 cp build/s2perm-*.log* /tmp/hv012-independent/ 2>/dev/null || true
 mkdir -p /tmp/hv012-independent/round-$i
 find build -name '*s2perm*.log*' -exec cp {} /tmp/hv012-independent/round-$i/ \; 2>/dev/null
 done
run linux make test-linux
run x86 make test-x86-stub
run static make check-arch-boundary check-offsets check-offsets-target
