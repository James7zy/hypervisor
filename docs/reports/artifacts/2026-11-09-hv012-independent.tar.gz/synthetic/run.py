from pathlib import Path
import re,sys,importlib.util,json
root=Path('/home/corsair/Music/virtual/hypervisor')
spec=importlib.util.spec_from_file_location('checker',root/'tests/check_s2perm_output.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path(__file__).parent
results=[]
for probe,kind in [(0,'ro'),(1,'xn')]:
 text=(out/(kind+'-original.log')).read_text(); lines=text.splitlines(True)
 fault=next(l for l in lines if '[hv] s2 fault:' in l)
 f=lines.index(fault); progress=[l for l in lines if 'survivor vm=' in l]
 # Compact authentic fixture headers/read line/fault/progress to isolate parser behavior.
 base=''.join(l for l in lines[:f] if 'survivor vm=' not in l)+fault
 post=progress[-1]
 before=post.replace(re.search(r'progress=([0-9a-f]+)',post)[1],'00000001')
 good=before+base+post
 cases={'good':good,'missing_fault':good.replace(fault,''),'wrong_fsc':good.replace('fsc=0xf','fsc=0x7'),
 'penetrated':good+'SVM: s2perm RO STORE SURVIVED\n','only_prefault_progress':before+base,
 'wrong_vm':good.replace('class=permission vm=0','class=permission vm=1'),
 'wrong_vcpu':good.replace('vcpu=0 pcpu=0 ipa','vcpu=1 pcpu=0 ipa'),
 'wrong_pcpu':good.replace('pcpu=0 ipa','pcpu=1 ipa'),
 'wrong_far':good.replace('far=0x4021','far=0xdead'),
 'wrong_elr':good.replace('elr=0x4021','elr=0xdead'),
 'split_records':good.replace(fault,fault.replace('class=permission vm=0','class=permission vm=1')+fault.replace('far=0x4021','far=0xdead')),
 'replayed_progress':before+base+before,
 'duplicate_wrong_fields':good.replace('class=permission vm=0','class=permission vm=1 vm=0'),
 'quoted_progress_only':before+base+'DIAGNOSTIC REPLAY: '+post,
 'inconsistent_esr':re.sub(r'esr=0x[0-9a-f]+','esr=0x0',good)}
 for name,log in cases.items():
  p=out/(kind+'-'+name+'.log');p.write_text(log);actual=m.check(log,probe)
  expected=name=='good'; results.append({'probe':kind,'case':name,'expected':expected,'actual':actual})
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for r in results: print(r)
