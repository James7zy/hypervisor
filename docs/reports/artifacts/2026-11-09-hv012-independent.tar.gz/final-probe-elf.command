make BUILD_DIR=build/test-s2perm HV_GUEST=svm_s2perm build/test-s2perm/svm/svm-s2perm-0.elf build/test-s2perm/svm/svm-s2perm-1.elf 
