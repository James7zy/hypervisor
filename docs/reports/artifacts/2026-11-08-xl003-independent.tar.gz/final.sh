#!/bin/bash
set -u
export PATH=/tmp/wrapbin:$PATH
export LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib
export CROSS_COMPILE=aarch64-linux-gnu-
export HV_NR_CPUS=4
D=/tmp/xl003-independent
cd /home/corsair/Music/virtual/hypervisor || exit 99
run() { local name=$1; shift; printf '%q ' "$@" > "$D/$name.command"; printf '\n' >> "$D/$name.command"; "$@" > "$D/$name.log" 2>&1; local rc=$?; echo "$rc" > "$D/$name.exit"; return "$rc"; }
run final-clean make clean || exit 99
run final-host make host-test || exit 99
run final-bounds make test-qemu-s2bounds || exit 99
for probe in 0 1 2; do
    run final-probe-$probe-raw env LINUX_IMAGE= HYPERVISOR_ELF=build/test-s2bounds/hypervisor.elf \
        SVM_BIN=build/test-s2bounds/svm/svm-s2bounds-$probe.bin SVM_BIN2=build/test-s2bounds/svm/svm-vm1.bin \
        timeout 10 ./scripts/run-qemu.sh </dev/null
    [ "$?" = 124 ] || exit 98
    run final-probe-$probe-check sh tests/check_svm_output.sh tests/svm/expect/s2bounds-$probe.txt tests/svm/expect/s2bounds-forbid.txt < "$D/final-probe-$probe-raw.log" || exit 97
done
run final-nm aarch64-linux-gnu-nm -n build/test-s2bounds/hypervisor.elf || exit 96
run final-source-diff git diff --exit-code HEAD -- Makefile hypervisor tests scripts || exit 95
run final-staged-diff git diff --cached --exit-code || exit 94
sha256sum hypervisor/arch/arm64/mmu/stage2_build.c hypervisor/arch/arm64/board/qemu_virt/linker.lds build/test-s2bounds/hypervisor.elf > "$D/final-sha256.log"
rm -f "$D/mutation-linux-test" "$D/mutation-svm-test"
echo done > "$D/final.done"
