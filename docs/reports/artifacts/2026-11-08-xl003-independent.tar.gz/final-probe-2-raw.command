env LINUX_IMAGE= HYPERVISOR_ELF=build/test-s2bounds/hypervisor.elf SVM_BIN=build/test-s2bounds/svm/svm-s2bounds-2.bin SVM_BIN2=build/test-s2bounds/svm/svm-vm1.bin timeout 10 ./scripts/run-qemu.sh 
