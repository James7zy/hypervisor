#!/bin/bash
export PATH=/tmp/wrapbin:$PATH
export LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib
export CROSS_COMPILE=aarch64-linux-gnu-
cd /home/corsair/Music/virtual/hypervisor || exit 99
D=/tmp/xl003-independent
run() { local name=$1; shift; printf '%q ' "$@" > "$D/$name.command"; printf '\n' >> "$D/$name.command"; "$@" > "$D/$name.log" 2>&1; local rc=$?; echo "$rc" > "$D/$name.exit"; }
run host make host-test
run clean make clean
run test make test
for n in 1 2 3; do run bounds-$n make test-qemu-s2bounds; done
run linux make test-linux
run x86 make test-x86-stub
run static make check-arch-boundary check-offsets check-offsets-target
echo done > "$D/gates.done"
