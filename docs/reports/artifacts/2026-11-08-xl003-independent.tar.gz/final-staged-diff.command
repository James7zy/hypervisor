git diff --cached --exit-code 
