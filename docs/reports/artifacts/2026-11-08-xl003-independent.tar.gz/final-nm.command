aarch64-linux-gnu-nm -n build/test-s2bounds/hypervisor.elf 
