make test-x86-stub 
