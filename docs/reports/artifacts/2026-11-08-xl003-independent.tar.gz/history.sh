#!/bin/bash
export PATH=/tmp/wrapbin:$PATH
export LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib
export CROSS_COMPILE=aarch64-linux-gnu-
ROOT=/home/corsair/Music/virtual/hypervisor
D=/tmp/xl003-independent
for rev in cec9d07 1ea66ee 246be0e; do
  mkdir -p "$D/history-$rev"
  git -C "$ROOT" archive "$rev" > "$D/history-$rev.tar" || exit 98
  tar -xf "$D/history-$rev.tar" -C "$D/history-$rev" || exit 98
  cd "$D/history-$rev" || exit 98
  make host-test > "$D/history-$rev-host.log" 2>&1; echo $? > "$D/history-$rev-host.exit"
  if [ "$rev" = 1ea66ee ]; then
    build/host/stage2_build_linux_test > "$D/red-linux.log" 2>&1; echo $? > "$D/red-linux.exit"
    build/host/stage2_build_svm_test > "$D/red-svm.log" 2>&1; echo $? > "$D/red-svm.exit"
  fi
done
