git diff --exit-code HEAD -- Makefile hypervisor tests scripts 
