sh tests/check_svm_output.sh tests/svm/expect/s2bounds-0.txt tests/svm/expect/s2bounds-forbid.txt 
