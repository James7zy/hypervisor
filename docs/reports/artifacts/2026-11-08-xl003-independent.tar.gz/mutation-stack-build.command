make BUILD_DIR=build/test-s2bounds HV_GUEST=svm_xvm2 all 
