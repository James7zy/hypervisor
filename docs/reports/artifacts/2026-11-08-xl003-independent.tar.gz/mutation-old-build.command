make BUILD_DIR=build/test-s2bounds HV_GUEST=svm_xvm2 all svm build/test-s2bounds/svm/svm-s2bounds-0.bin build/test-s2bounds/svm/svm-s2bounds-1.bin 
