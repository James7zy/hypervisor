#!/bin/bash
set -u
export PATH=/tmp/wrapbin:$PATH
export LD_LIBRARY_PATH=/tmp/tc/usr/lib/x86_64-linux-gnu:/tmp/tc/usr/lib
export CROSS_COMPILE=aarch64-linux-gnu-
export HV_NR_CPUS=4
D=/tmp/xl003-independent
cd "$D/mutation" || exit 99
run() { local name=$1; shift; printf '%q ' "$@" > "$D/$name.command"; printf '\n' >> "$D/$name.command"; "$@" > "$D/$name.log" 2>&1; local rc=$?; echo "$rc" > "$D/$name.exit"; return "$rc"; }
builder=hypervisor/arch/arm64/mmu/stage2_build.c
linker=hypervisor/arch/arm64/board/qemu_virt/linker.lds
cp "$builder" "$D/mutation-builder-original"
cp "$linker" "$D/mutation-linker-original"
trap 'cp "$D/mutation-builder-original" "$builder"; cp "$D/mutation-linker-original" "$linker"' EXIT
cp "$D/old-builder.c" "$builder"
for profile in linux svm; do
    flags=()
    if [ "$profile" = svm ]; then flags=(-DCONFIG_GUEST_SVM=1 -DCONFIG_SVM_XVM2=1); fi
    run mutation-host-$profile-build gcc -Wall -Wextra -Werror -O2 -g -fno-builtin -U_FORTIFY_SOURCE -std=c11 \
        -Ihypervisor/include -Ihypervisor/arch/x86/include -Ihypervisor/arch/arm64/board/qemu_virt \
        -Ihypervisor/arch/arm64/mmu -Itests/host -DCONFIG_NR_CPUS=4 -DCONFIG_NR_VMS=2 \
        "${flags[@]}" -o "$D/mutation-$profile-test" "$D/red-test.c" \
        "$builder" hypervisor/common/mmu/s2_table.c hypervisor/common/vm/vm_configs.c || exit 90
    run mutation-host-$profile "$D/mutation-$profile-test"
    [ "$?" = 1 ] || exit 91
done
run mutation-old-build make BUILD_DIR=build/test-s2bounds HV_GUEST=svm_xvm2 all svm build/test-s2bounds/svm/svm-s2bounds-0.bin build/test-s2bounds/svm/svm-s2bounds-1.bin || exit 92
for probe in 0 1; do
    run mutation-probe-$probe-raw env LINUX_IMAGE= HYPERVISOR_ELF=build/test-s2bounds/hypervisor.elf \
        SVM_BIN=build/test-s2bounds/svm/svm-s2bounds-$probe.bin SVM_BIN2=build/test-s2bounds/svm/svm-vm1.bin \
        timeout 10 ./scripts/run-qemu.sh </dev/null
    [ "$?" = 124 ] || exit 93
    run mutation-probe-$probe-check sh tests/check_svm_output.sh tests/svm/expect/s2bounds-$probe.txt tests/svm/expect/s2bounds-forbid.txt < "$D/mutation-probe-$probe-raw.log"
    [ "$?" = 1 ] || exit 94
    grep -q '^SVM: s2bounds SURVIVED' "$D/mutation-probe-$probe-raw.log" || exit 95
    grep -q '^\[hv\] SVM HVC: done (x1=0x10001)' "$D/mutation-probe-$probe-raw.log" || exit 96
done
cp "$D/mutation-builder-original" "$builder"
run mutation-post-old-clean make clean || exit 97
python3 - "$linker" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]); s=p.read_text(); assert s.count('. += 0x4000;') == 1
p.write_text(s.replace('. += 0x4000;', '. += 0x200000;'))
PY
run mutation-stack-build make BUILD_DIR=build/test-s2bounds HV_GUEST=svm_xvm2 all
[ "$?" = 2 ] || exit 98
grep -q 'HV overlaps SVM RAM backing' "$D/mutation-stack-build.log" || exit 98
cp "$D/mutation-linker-original" "$linker"
run mutation-final-clean make clean || exit 99
run mutation-final-host make host-test || exit 99
run mutation-final-bounds make test-qemu-s2bounds || exit 99
run mutation-final-nm aarch64-linux-gnu-nm -n build/test-s2bounds/hypervisor.elf || exit 99
cmp "$builder" "$D/mutation-builder-original" || exit 99
cmp "$linker" "$D/mutation-linker-original" || exit 99
echo 'source exact restore; clean rebuilt host + all three probes passed' > "$D/mutations.done"
